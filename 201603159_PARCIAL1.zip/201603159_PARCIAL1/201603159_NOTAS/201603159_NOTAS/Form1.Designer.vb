﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CIN = New System.Windows.Forms.CheckBox()
        Me.CLEN = New System.Windows.Forms.CheckBox()
        Me.CQUI = New System.Windows.Forms.CheckBox()
        Me.CTE = New System.Windows.Forms.CheckBox()
        Me.CMU = New System.Windows.Forms.CheckBox()
        Me.CCI = New System.Windows.Forms.CheckBox()
        Me.CSO = New System.Windows.Forms.CheckBox()
        Me.CED = New System.Windows.Forms.CheckBox()
        Me.CFI = New System.Windows.Forms.CheckBox()
        Me.CMA = New System.Windows.Forms.CheckBox()
        Me.TNOMBRE = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.TIN = New System.Windows.Forms.TextBox()
        Me.TLE = New System.Windows.Forms.TextBox()
        Me.TQUI = New System.Windows.Forms.TextBox()
        Me.TTE = New System.Windows.Forms.TextBox()
        Me.TMU = New System.Windows.Forms.TextBox()
        Me.TED = New System.Windows.Forms.TextBox()
        Me.TCI = New System.Windows.Forms.TextBox()
        Me.TSO = New System.Windows.Forms.TextBox()
        Me.TFI = New System.Windows.Forms.TextBox()
        Me.TMA = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PROMEDIOToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ELIMINARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SALIRToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.C10 = New System.Windows.Forms.CheckBox()
        Me.C9 = New System.Windows.Forms.CheckBox()
        Me.C8 = New System.Windows.Forms.CheckBox()
        Me.C7 = New System.Windows.Forms.CheckBox()
        Me.C6 = New System.Windows.Forms.CheckBox()
        Me.C4 = New System.Windows.Forms.CheckBox()
        Me.C3 = New System.Windows.Forms.CheckBox()
        Me.C5 = New System.Windows.Forms.CheckBox()
        Me.C2 = New System.Windows.Forms.CheckBox()
        Me.C1 = New System.Windows.Forms.CheckBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Black", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(127, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(282, 30)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "CÁLCULO DEL PROMEDIO "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(19, 70)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(300, 21)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "INGRESAR NOMBRE DEL ESTUDIANTE ="
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CIN)
        Me.GroupBox1.Controls.Add(Me.CLEN)
        Me.GroupBox1.Controls.Add(Me.CQUI)
        Me.GroupBox1.Controls.Add(Me.CTE)
        Me.GroupBox1.Controls.Add(Me.CMU)
        Me.GroupBox1.Controls.Add(Me.CCI)
        Me.GroupBox1.Controls.Add(Me.CSO)
        Me.GroupBox1.Controls.Add(Me.CED)
        Me.GroupBox1.Controls.Add(Me.CFI)
        Me.GroupBox1.Controls.Add(Me.CMA)
        Me.GroupBox1.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(179, 117)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(194, 340)
        Me.GroupBox1.TabIndex = 11
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "CURSOS:"
        '
        'CIN
        '
        Me.CIN.AutoSize = True
        Me.CIN.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CIN.Location = New System.Drawing.Point(3, 307)
        Me.CIN.Name = "CIN"
        Me.CIN.Size = New System.Drawing.Size(81, 25)
        Me.CIN.TabIndex = 10
        Me.CIN.Text = "INGLES"
        Me.CIN.UseVisualStyleBackColor = True
        '
        'CLEN
        '
        Me.CLEN.AutoSize = True
        Me.CLEN.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CLEN.Location = New System.Drawing.Point(3, 276)
        Me.CLEN.Name = "CLEN"
        Me.CLEN.Size = New System.Drawing.Size(104, 25)
        Me.CLEN.TabIndex = 9
        Me.CLEN.Text = "LENGUAJE"
        Me.CLEN.UseVisualStyleBackColor = True
        '
        'CQUI
        '
        Me.CQUI.AutoSize = True
        Me.CQUI.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CQUI.Location = New System.Drawing.Point(3, 245)
        Me.CQUI.Name = "CQUI"
        Me.CQUI.Size = New System.Drawing.Size(94, 25)
        Me.CQUI.TabIndex = 8
        Me.CQUI.Text = "QUIMICA"
        Me.CQUI.UseVisualStyleBackColor = True
        '
        'CTE
        '
        Me.CTE.AutoSize = True
        Me.CTE.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CTE.Location = New System.Drawing.Point(3, 214)
        Me.CTE.Name = "CTE"
        Me.CTE.Size = New System.Drawing.Size(84, 25)
        Me.CTE.TabIndex = 7
        Me.CTE.Text = "TEATRO"
        Me.CTE.UseVisualStyleBackColor = True
        '
        'CMU
        '
        Me.CMU.AutoSize = True
        Me.CMU.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CMU.Location = New System.Drawing.Point(3, 183)
        Me.CMU.Name = "CMU"
        Me.CMU.Size = New System.Drawing.Size(87, 25)
        Me.CMU.TabIndex = 6
        Me.CMU.Text = "MUSICA"
        Me.CMU.UseVisualStyleBackColor = True
        '
        'CCI
        '
        Me.CCI.AutoSize = True
        Me.CCI.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CCI.Location = New System.Drawing.Point(3, 121)
        Me.CCI.Name = "CCI"
        Me.CCI.Size = New System.Drawing.Size(185, 25)
        Me.CCI.TabIndex = 5
        Me.CCI.Text = "CIENCIAS NATURALES"
        Me.CCI.UseVisualStyleBackColor = True
        '
        'CSO
        '
        Me.CSO.AutoSize = True
        Me.CSO.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CSO.Location = New System.Drawing.Point(5, 90)
        Me.CSO.Name = "CSO"
        Me.CSO.Size = New System.Drawing.Size(99, 25)
        Me.CSO.TabIndex = 4
        Me.CSO.Text = "SOCIALES"
        Me.CSO.UseVisualStyleBackColor = True
        '
        'CED
        '
        Me.CED.AutoSize = True
        Me.CED.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CED.Location = New System.Drawing.Point(3, 152)
        Me.CED.Name = "CED"
        Me.CED.Size = New System.Drawing.Size(166, 25)
        Me.CED.TabIndex = 3
        Me.CED.Text = "EDUCACION FISICA"
        Me.CED.UseVisualStyleBackColor = True
        '
        'CFI
        '
        Me.CFI.AutoSize = True
        Me.CFI.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CFI.Location = New System.Drawing.Point(5, 59)
        Me.CFI.Name = "CFI"
        Me.CFI.Size = New System.Drawing.Size(74, 25)
        Me.CFI.TabIndex = 2
        Me.CFI.Text = "FISICA"
        Me.CFI.UseVisualStyleBackColor = True
        '
        'CMA
        '
        Me.CMA.AutoSize = True
        Me.CMA.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CMA.Location = New System.Drawing.Point(5, 28)
        Me.CMA.Name = "CMA"
        Me.CMA.Size = New System.Drawing.Size(123, 25)
        Me.CMA.TabIndex = 1
        Me.CMA.Text = "MATEMATICA"
        Me.CMA.UseVisualStyleBackColor = True
        '
        'TNOMBRE
        '
        Me.TNOMBRE.Location = New System.Drawing.Point(325, 73)
        Me.TNOMBRE.Name = "TNOMBRE"
        Me.TNOMBRE.Size = New System.Drawing.Size(211, 20)
        Me.TNOMBRE.TabIndex = 12
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.TIN)
        Me.GroupBox3.Controls.Add(Me.TLE)
        Me.GroupBox3.Controls.Add(Me.TQUI)
        Me.GroupBox3.Controls.Add(Me.TTE)
        Me.GroupBox3.Controls.Add(Me.TMU)
        Me.GroupBox3.Controls.Add(Me.TED)
        Me.GroupBox3.Controls.Add(Me.TCI)
        Me.GroupBox3.Controls.Add(Me.TSO)
        Me.GroupBox3.Controls.Add(Me.TFI)
        Me.GroupBox3.Controls.Add(Me.TMA)
        Me.GroupBox3.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(379, 117)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(181, 340)
        Me.GroupBox3.TabIndex = 13
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "NOTAS:"
        '
        'TIN
        '
        Me.TIN.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TIN.Location = New System.Drawing.Point(20, 307)
        Me.TIN.Name = "TIN"
        Me.TIN.Size = New System.Drawing.Size(129, 20)
        Me.TIN.TabIndex = 22
        Me.TIN.Visible = False
        '
        'TLE
        '
        Me.TLE.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TLE.Location = New System.Drawing.Point(20, 276)
        Me.TLE.Name = "TLE"
        Me.TLE.Size = New System.Drawing.Size(129, 20)
        Me.TLE.TabIndex = 18
        Me.TLE.Visible = False
        '
        'TQUI
        '
        Me.TQUI.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TQUI.Location = New System.Drawing.Point(20, 245)
        Me.TQUI.Name = "TQUI"
        Me.TQUI.Size = New System.Drawing.Size(129, 20)
        Me.TQUI.TabIndex = 17
        Me.TQUI.Visible = False
        '
        'TTE
        '
        Me.TTE.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TTE.Location = New System.Drawing.Point(20, 214)
        Me.TTE.Name = "TTE"
        Me.TTE.Size = New System.Drawing.Size(129, 20)
        Me.TTE.TabIndex = 16
        Me.TTE.Visible = False
        '
        'TMU
        '
        Me.TMU.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TMU.Location = New System.Drawing.Point(20, 183)
        Me.TMU.Name = "TMU"
        Me.TMU.Size = New System.Drawing.Size(129, 20)
        Me.TMU.TabIndex = 12
        Me.TMU.Visible = False
        '
        'TED
        '
        Me.TED.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TED.Location = New System.Drawing.Point(18, 152)
        Me.TED.Name = "TED"
        Me.TED.Size = New System.Drawing.Size(129, 20)
        Me.TED.TabIndex = 11
        Me.TED.Visible = False
        '
        'TCI
        '
        Me.TCI.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TCI.Location = New System.Drawing.Point(20, 121)
        Me.TCI.Name = "TCI"
        Me.TCI.Size = New System.Drawing.Size(129, 20)
        Me.TCI.TabIndex = 10
        Me.TCI.Visible = False
        '
        'TSO
        '
        Me.TSO.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TSO.Location = New System.Drawing.Point(20, 90)
        Me.TSO.Name = "TSO"
        Me.TSO.Size = New System.Drawing.Size(129, 20)
        Me.TSO.TabIndex = 2
        Me.TSO.Visible = False
        '
        'TFI
        '
        Me.TFI.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TFI.Location = New System.Drawing.Point(18, 59)
        Me.TFI.Name = "TFI"
        Me.TFI.Size = New System.Drawing.Size(129, 20)
        Me.TFI.TabIndex = 1
        Me.TFI.Visible = False
        '
        'TMA
        '
        Me.TMA.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TMA.Location = New System.Drawing.Point(18, 33)
        Me.TMA.Name = "TMA"
        Me.TMA.Size = New System.Drawing.Size(129, 20)
        Me.TMA.TabIndex = 0
        Me.TMA.Visible = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(572, 25)
        Me.MenuStrip1.TabIndex = 16
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PROMEDIOToolStripMenuItem, Me.ELIMINARToolStripMenuItem, Me.SALIRToolStripMenuItem})
        Me.ToolStripMenuItem1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(58, 21)
        Me.ToolStripMenuItem1.Text = "MENU"
        '
        'PROMEDIOToolStripMenuItem
        '
        Me.PROMEDIOToolStripMenuItem.Name = "PROMEDIOToolStripMenuItem"
        Me.PROMEDIOToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.PROMEDIOToolStripMenuItem.Text = "PROMEDIO"
        '
        'ELIMINARToolStripMenuItem
        '
        Me.ELIMINARToolStripMenuItem.Name = "ELIMINARToolStripMenuItem"
        Me.ELIMINARToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ELIMINARToolStripMenuItem.Text = "ELIMINAR"
        '
        'SALIRToolStripMenuItem
        '
        Me.SALIRToolStripMenuItem.Name = "SALIRToolStripMenuItem"
        Me.SALIRToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.SALIRToolStripMenuItem.Text = "SALIR"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.C10)
        Me.GroupBox2.Controls.Add(Me.C9)
        Me.GroupBox2.Controls.Add(Me.C8)
        Me.GroupBox2.Controls.Add(Me.C7)
        Me.GroupBox2.Controls.Add(Me.C6)
        Me.GroupBox2.Controls.Add(Me.C4)
        Me.GroupBox2.Controls.Add(Me.C3)
        Me.GroupBox2.Controls.Add(Me.C5)
        Me.GroupBox2.Controls.Add(Me.C2)
        Me.GroupBox2.Controls.Add(Me.C1)
        Me.GroupBox2.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(23, 117)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(138, 340)
        Me.GroupBox2.TabIndex = 12
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "EQUIVALENCIA:"
        '
        'C10
        '
        Me.C10.AutoSize = True
        Me.C10.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C10.Location = New System.Drawing.Point(55, 307)
        Me.C10.Name = "C10"
        Me.C10.Size = New System.Drawing.Size(15, 14)
        Me.C10.TabIndex = 10
        Me.C10.UseVisualStyleBackColor = True
        '
        'C9
        '
        Me.C9.AutoSize = True
        Me.C9.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C9.Location = New System.Drawing.Point(55, 276)
        Me.C9.Name = "C9"
        Me.C9.Size = New System.Drawing.Size(15, 14)
        Me.C9.TabIndex = 9
        Me.C9.UseVisualStyleBackColor = True
        '
        'C8
        '
        Me.C8.AutoSize = True
        Me.C8.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C8.Location = New System.Drawing.Point(55, 245)
        Me.C8.Name = "C8"
        Me.C8.Size = New System.Drawing.Size(15, 14)
        Me.C8.TabIndex = 8
        Me.C8.UseVisualStyleBackColor = True
        '
        'C7
        '
        Me.C7.AutoSize = True
        Me.C7.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C7.Location = New System.Drawing.Point(55, 214)
        Me.C7.Name = "C7"
        Me.C7.Size = New System.Drawing.Size(15, 14)
        Me.C7.TabIndex = 7
        Me.C7.UseVisualStyleBackColor = True
        '
        'C6
        '
        Me.C6.AutoSize = True
        Me.C6.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C6.Location = New System.Drawing.Point(55, 183)
        Me.C6.Name = "C6"
        Me.C6.Size = New System.Drawing.Size(15, 14)
        Me.C6.TabIndex = 6
        Me.C6.UseVisualStyleBackColor = True
        '
        'C4
        '
        Me.C4.AutoSize = True
        Me.C4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C4.Location = New System.Drawing.Point(55, 121)
        Me.C4.Name = "C4"
        Me.C4.Size = New System.Drawing.Size(15, 14)
        Me.C4.TabIndex = 5
        Me.C4.UseVisualStyleBackColor = True
        '
        'C3
        '
        Me.C3.AutoSize = True
        Me.C3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C3.Location = New System.Drawing.Point(57, 90)
        Me.C3.Name = "C3"
        Me.C3.Size = New System.Drawing.Size(15, 14)
        Me.C3.TabIndex = 4
        Me.C3.UseVisualStyleBackColor = True
        '
        'C5
        '
        Me.C5.AutoSize = True
        Me.C5.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C5.Location = New System.Drawing.Point(55, 152)
        Me.C5.Name = "C5"
        Me.C5.Size = New System.Drawing.Size(15, 14)
        Me.C5.TabIndex = 3
        Me.C5.UseVisualStyleBackColor = True
        '
        'C2
        '
        Me.C2.AutoSize = True
        Me.C2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C2.Location = New System.Drawing.Point(57, 59)
        Me.C2.Name = "C2"
        Me.C2.Size = New System.Drawing.Size(15, 14)
        Me.C2.TabIndex = 2
        Me.C2.UseVisualStyleBackColor = True
        '
        'C1
        '
        Me.C1.AutoSize = True
        Me.C1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C1.Location = New System.Drawing.Point(57, 28)
        Me.C1.Name = "C1"
        Me.C1.Size = New System.Drawing.Size(15, 14)
        Me.C1.TabIndex = 1
        Me.C1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(572, 485)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.TNOMBRE)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "NOTAS"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents CIN As CheckBox
    Friend WithEvents CLEN As CheckBox
    Friend WithEvents CQUI As CheckBox
    Friend WithEvents CTE As CheckBox
    Friend WithEvents CMU As CheckBox
    Friend WithEvents CCI As CheckBox
    Friend WithEvents CSO As CheckBox
    Friend WithEvents CED As CheckBox
    Friend WithEvents CFI As CheckBox
    Friend WithEvents CMA As CheckBox
    Friend WithEvents TNOMBRE As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents TIN As TextBox
    Friend WithEvents TLE As TextBox
    Friend WithEvents TQUI As TextBox
    Friend WithEvents TTE As TextBox
    Friend WithEvents TMU As TextBox
    Friend WithEvents TED As TextBox
    Friend WithEvents TCI As TextBox
    Friend WithEvents TSO As TextBox
    Friend WithEvents TFI As TextBox
    Friend WithEvents TMA As TextBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents PROMEDIOToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ELIMINARToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SALIRToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents C10 As CheckBox
    Friend WithEvents C9 As CheckBox
    Friend WithEvents C8 As CheckBox
    Friend WithEvents C7 As CheckBox
    Friend WithEvents C6 As CheckBox
    Friend WithEvents C4 As CheckBox
    Friend WithEvents C3 As CheckBox
    Friend WithEvents C5 As CheckBox
    Friend WithEvents C2 As CheckBox
    Friend WithEvents C1 As CheckBox
End Class
